import { PatientForm } from "@/components/patients/patient-form"

export default function NewPatientPage() {
  return <PatientForm />
}

