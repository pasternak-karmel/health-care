import WorkflowForm from "@/components/workflows/workflow-form";

export default function NewWorkflowPage() {
    return (
        <WorkflowForm />
    )
}