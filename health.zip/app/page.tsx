"use client";
import HeroSection from "@/components/landing/hero-section";

export default function Home() {
  return (
    <div>
      <HeroSection />
    </div>
  );
}
